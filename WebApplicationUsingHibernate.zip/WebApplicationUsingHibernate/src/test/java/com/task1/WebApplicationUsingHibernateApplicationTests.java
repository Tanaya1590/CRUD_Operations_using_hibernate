/*
package com.task1;




@SpringBootTest
class WebApplicationUsingHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/